﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class UserHomeController : Controller
    {
        // GET: UserHome
        public ActionResult Home()
        {
            return View();
        }
    }
}