﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class LoginController : Controller
    {
        Self_Learning_TutorialsEntities4 db = new Self_Learning_TutorialsEntities4();

        // GET: Login
        public ActionResult Login()
        {
            //var a=new SelectListItem
            //ViewBag.Name = new SelectList(db.tblRoles, "RoleId", "RoleName");
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginCredentials l1)
        {
            if (ModelState.IsValid)
            {
                if (l1.UserRole == "User")
                {
                    var user = db.tblUsers.Where(u => u.Email == l1.Email && u.Password == l1.Password).FirstOrDefault();

                    if (user != null)
                    {
                        Session["Email"] = l1.Email;
                        return RedirectToAction("");
                    }
                    else
                    {
                        ModelState.AddModelError("","Invalid Login Credentials!");
                        return View();

                    }
                }
                else if (l1.UserRole == "Mentor")
                {
                    var mentor = db.tblMentors.Where(m => m.Email == l1.Email && m.Password == l1.Password).FirstOrDefault();
                    if (mentor != null)
                    {
                        Session["Email"] = l1.Email;
                        return RedirectToAction("");
                    }
                    else
                    {
                        ModelState.AddModelError("","Invalid  Login Credentials!");
                        return View();
                    }
                        
                }
            }

            return View(l1);
        }
    }
}