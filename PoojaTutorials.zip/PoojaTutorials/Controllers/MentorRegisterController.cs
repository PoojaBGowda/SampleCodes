﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class MentorRegisterController : Controller
    {
        Self_Learning_TutorialsEntities4 db = new Self_Learning_TutorialsEntities4();

        // GET: MentorRegister
        public ActionResult MentorRegister()
        {
            return View();
        }
        [HttpPost]
        public ActionResult MentorRegister(tblMentor m1)
        {
            if (ModelState.IsValid)
            {
                m1.RoleId = 2;
                db.ps_MentorRegister(m1.Name, m1.Email, m1.Password, m1.ConfirmPassword,m1.PhoneNum,m1.Experience,m1.Technology, m1.RoleId);
                db.SaveChanges();
                return RedirectToAction("Login","Login");
            }

            return View(m1);
        }
        [HttpPost]
        public ActionResult doesEmailExist(string Email)
        {
            var user = db.tblUsers.Where(u => u.Email == Email).FirstOrDefault();
            return Json(user == null);
        }
    }
}