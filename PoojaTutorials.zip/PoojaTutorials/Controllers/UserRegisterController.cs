﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class UserRegisterController : Controller
    {
        Self_Learning_TutorialsEntities4 db = new Self_Learning_TutorialsEntities4();

        // GET: UserRegister
        public ActionResult UserRegister()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UserRegister(tblUser u1)
        {
            if(ModelState.IsValid)
            {
                u1.RoleId = 1;
                db.ps_UserRegister(u1.Name,u1.Email,u1.Password,u1.ConfirmPassword,u1.RoleId);
                db.SaveChanges();
                return RedirectToAction("Login","Login");
            }
            
            return View(u1);
        }
        [HttpPost]
        public ActionResult doesEmailExist(string Email)
        {
            var user = db.tblUsers.Where(u => u.Email == Email).FirstOrDefault();
            return Json(user == null);
        }
    }
}