﻿using PoojaTutorials.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class UserHomeController : Controller
    {
        Self_Learning_TutorialsEntities1 db = new Self_Learning_TutorialsEntities1();
        Self_Learning_TutorialsEntities5 sf = new Self_Learning_TutorialsEntities5();

        // GET: UserHome
        public ActionResult Home()
        {
            return View();
        }
        //[HttpPost]
        public JsonResult Search(string term)
        {
            List<string> course;
            
            course = db.tblcourses.Where(x => x.CourseName.StartsWith(term)).Select(y=>y.CourseName).ToList();
            
            return Json(course,JsonRequestBehavior.AllowGet);
        }

        public ActionResult Forums()
        {
             var result = sf.ps_Getanswers().ToList();
            List<Forums> model = new List<Forums>();
            foreach (var item in result)
            {
                model.Add(new Forums
                {
                    Questions = item.Questions,
                    Answers = item.Answers,
                    postedBy = item.Posted_by,
                    AnsweredBy = item.Answered_by,
                    Question_Id=item.QId
                });
               
            }
            return View(model);
        }
        public ActionResult MentorDetails()
        {
            var a = db.tblMentors;
            return View(a);
        }
    }
}