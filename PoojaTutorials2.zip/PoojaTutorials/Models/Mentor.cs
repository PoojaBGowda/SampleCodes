﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Models
{
    public class Mentor
    {
        public int MentorId { get; set; }
        [Required]
        [MinLength(4)]
        [MaxLength(20)]
        [RegularExpression(@"^[a-zA-Z][a-zA-Z\\s ]+$", ErrorMessage = "Only Alphabets are allowed")]
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        [Remote("doesEmailExist", "MentorRegister", HttpMethod = "Post", ErrorMessage = "This Email is registered by another user. Please try with another Email.")]
        public string Email { get; set; }
        [Required]
        [Phone]
        [Display(Name = "PhoneNum")]
        public string PhoneNum { get; set; }
        [Required]
        [Display(Name = "Experience")]
        public int Experience { get; set; }
        [Required]
        [Display(Name = "Technology")]
        public string Technology { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [Display(Name = "Password")]
        public string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        [Display(Name = "ConfirmPassword")]
        public string ConfirmPassword { get; set; }
        public int RoleId { get; set; }
        public System.DateTime Mentor_Timestamp { get; set; }
    }
}