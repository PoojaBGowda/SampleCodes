﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Models
{
    public class MentorEdit
    {
        
        [EmailAddress]
        [Display(Name = "Email")]
        [Remote("doesEmailExist", "MentorRegister", HttpMethod = "Post", ErrorMessage = "This Email is registered by another user. Please try with another Email.")]
        public string Email { get; set; }
        [Phone]
        [Display(Name = "PhoneNum")]
        public string PhoneNum { get; set; }
        [Display(Name = "Experience")]
        public int? Experience { get; set; }
        [Display(Name = "Technology")]
        public string Technology { get; set; }
        
    }
}