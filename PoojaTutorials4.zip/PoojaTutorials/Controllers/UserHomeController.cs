﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Windows.Forms;

namespace PoojaTutorials.Controllers
{
    public class UserHomeController : Controller
    {
        Self_Learning_TutorialsEntities1 db = new Self_Learning_TutorialsEntities1();
        Self_Learning_TutorialsEntities5 sf = new Self_Learning_TutorialsEntities5();

        // GET: UserHome
        
        public ActionResult Home()
        {
            if (Session["Email"].ToString() != null)
            {
                return View();
            }
            else
            return RedirectToAction("Login", "Login");

        }
       
        public JsonResult Search(string term)
        {

            List<string> course;
            
            course = db.tblcourses.Where(x => x.CourseName.StartsWith(term)).Select(y=>y.CourseName).ToList();
            
            return Json(course,JsonRequestBehavior.AllowGet);
        }

        public ActionResult Forums()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    var result = sf.ps_Getanswers().ToList();
                    List<Forums> model = new List<Forums>();
                    foreach (var item in result)
                    {
                        model.Add(new Forums
                        {
                            Questions = item.Questions,
                            Answers = item.Answers,
                            postedBy = item.Posted_by,
                            AnsweredBy = item.Answered_by,
                            Question_Id = item.QId
                        });

                    }
                    return View(model);
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");

        }
        public ActionResult MentorDetails()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    var a = db.tblMentors;
                    return View(a);
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");

        }

        [HttpPost]
        public ActionResult UserQuestion(string QuestionBox)
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    string a = Session["Email"].ToString();
                    var user = db.tblUsers.Where(x => x.Email == a).FirstOrDefault();
                    tblQForum quest = new tblQForum();
                    quest.Questions = QuestionBox;
                    quest.Posted_by = user.Name;
                    db.tblQForums.Add(quest);
                    db.SaveChanges();
                    return Content("Question has been submitted successfully");
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");
        }

        [HttpPost]
        public ActionResult SearchCourse(string search)
        {
            switch (search)
            {
                case "C#": return RedirectToAction("Csharp", "Courses");
                case "JavaScript": return RedirectToAction("Javascript", "Courses");
                case "JQuery": return RedirectToAction("JQuery", "Courses");
                case "AngularJS": return RedirectToAction("AngularJS", "Courses");
                case "MVC": return RedirectToAction("MVC", "Courses");
                case "ASP.NET": return RedirectToAction("Csharp", "Courses");
                default: MessageBox.Show("No results found");
                    return RedirectToAction("Home","UserHome");
            }
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Login", "Login");
        }

        public ActionResult ChangePwd()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");

        }

        [HttpPost]
        public ActionResult ChangePwd(Change ch)
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    if (ModelState.IsValid)
                    {
                        var user = db.tblUsers.Where(x => x.Password == ch.OldPassword && x.Email == ch.Email).FirstOrDefault();
                        if (user != null)
                        {
                            user.Password = ch.NewPassword;
                            db.SaveChanges();
                            return RedirectToAction("Login", "Login");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid  Credentials!");
                            return View();
                        }
                    }
                    else
                        return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");
        }

    }
}