﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
   
    public class MentorHomeController : Controller
    {
        Self_Learning_TutorialsEntities5 sf = new Self_Learning_TutorialsEntities5();
        Self_Learning_TutorialsEntities1 db = new Self_Learning_TutorialsEntities1();
        // GET: MentorHome
        
        public ActionResult Forums()
        {
            var result = sf.ps_Getquestions().ToList();
            List<Forums> model = new List<Forums>();
            foreach (var item in result)
            {
                model.Add(new Forums
                {
                    Questions = item.Questions,
                    postedBy = item.Posted_by,
                    Question_Id = item.QId
                });

            }
            return View(model);
        }

        [HttpPost]
        public ActionResult MentorAnswer(FormCollection form, int id)
        {
            string a = Session["Email"].ToString();
            var mentor = db.tblMentors.Where(x => x.Email == a).FirstOrDefault();
            tblAForum quest = new tblAForum();
            quest.QId = id;
            quest.Answered_by = mentor.Name;
            quest.Answers = form["AnswerBox"].ToString();
            db.tblAForums.Add(quest);
            db.SaveChanges();
            return Content("Question has been submitted successfully");
        }
    }
}