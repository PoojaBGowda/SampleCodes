﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Controllers
{
    public class CoursesController : Controller
    {
        // GET: Courses
        public ActionResult Javascript()
        {
            return View();
        }
        public ActionResult JQuery()
        {
            return View();
        }
        public ActionResult AngularJS()
        {
            return View();
        }
        public ActionResult MVC()
        {
            return View();
        }

    }
}